package com.example.submissionawal.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.example.submissionawal.data.repository.StoryRepository

class StoryViewModel(private val repository: StoryRepository) : ViewModel() {
    fun story() = repository.getStory()

}
