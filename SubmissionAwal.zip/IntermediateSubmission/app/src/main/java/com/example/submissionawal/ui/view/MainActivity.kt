package com.example.submissionawal.ui.view

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submissionawal.adapter.ListAdapterStory
import com.example.submissionawal.databinding.ActivityMainBinding
import com.example.submissionawal.help.ResultHelp
import com.example.submissionawal.ui.viewmodel.MainViewModel
import com.example.submissionawal.ui.viewmodel.StoryViewModel
import com.example.submissionawal.ui.viewmodelfactory.StoryViewModelFactory
import com.example.submissionawal.ui.viewmodelfactory.ViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }

    private val storyViewModel by viewModels<StoryViewModel> {
        StoryViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.show()

        viewModel.getSession().observe(this@MainActivity) { user ->
            if (!user.isLogin) {
                startActivity(Intent(this@MainActivity, WelcomeActivity::class.java))
                finish()
            } else {
                setupButton()
            }
        }

        binding.addItem.setOnClickListener {
            startActivity(Intent(this@MainActivity, AddStoryActivity::class.java))
        }

        binding.actionKeluar.setOnClickListener {
            viewModel.logout()
        }

        setupView()
        setupButton()
    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
    }

    private fun setupButton() {
        lifecycleScope.launch {
            storyViewModel.story().observe(this@MainActivity) { story ->
                when (story) {
                    is ResultHelp.Error -> {
                        binding.progressIndicator.visibility = View.INVISIBLE
                        val error = story.error
                        Toast.makeText(this@MainActivity, error, Toast.LENGTH_SHORT).show()
                    }

                    is ResultHelp.Loading -> {
                        showLoading(true)
                    }

                    is ResultHelp.Success -> {
                        showLoading(false)
                        val adapter = ListAdapterStory()
                        adapter.submitList(story.data)
                        binding.itemRowStory.layoutManager = LinearLayoutManager(this@MainActivity)
                        binding.itemRowStory.adapter = adapter
                    }
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressIndicator.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}