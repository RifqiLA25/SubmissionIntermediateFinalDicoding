package com.example.submissionawal.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import com.example.submissionawal.data.remote.pref.UserPreference
import com.example.submissionawal.data.remote.response.ErrorResponse
import com.example.submissionawal.data.remote.response.ListItemStory
import com.example.submissionawal.data.remote.retrofit.ApiService
import com.example.submissionawal.help.ResultHelp
import com.google.gson.Gson
import retrofit2.HttpException


class StoryRepository private constructor(
    private val apiService: ApiService,
    private val userPreference: UserPreference
) {
    fun getStory(): LiveData<ResultHelp<List<ListItemStory>>> = liveData {
        emit(ResultHelp.Loading)
        try {
            val response = apiService.getStories()
            emit(ResultHelp.Success(response.listStory))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, ErrorResponse::class.java)
            emit(ResultHelp.Error(errorResponse.message))
        } catch (e: Exception) {
            emit(ResultHelp.Error(e.message ?: "Error"))
        }
    }

    companion object {
        fun getInstance(
            apiService: ApiService,
            userPreference: UserPreference
        ) = StoryRepository(apiService, userPreference)
    }
}