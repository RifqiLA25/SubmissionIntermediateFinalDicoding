package com.example.submissionawal.data.local.room

class UserDatabase(
    val email: String,
    val token: String,
    val isLogin: Boolean = false
)